# CAST-Jenkins-Pipeline
Jenkins Pipeline script to orchestrate an application build process with CAST scan
